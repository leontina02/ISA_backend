INSERT INTO book (title, author) VALUES ('Book Title 1', 'Author 1');
INSERT INTO book (title, author) VALUES ('Book Title 2', 'Author 2');
INSERT INTO book (title, author) VALUES ('Book Title 3', 'Author 3');
